function [boundary, info] = boundaryFollow(BW, conn)
%BOUNDARYFOLLOW Follow one ordered object boundary in a binary image.
if nargin < 2
    conn = 8;
end

if conn ~= 4 && conn ~= 8
    error('boundaryFollow:InvalidConnectivity', 'Connectivity must be 4 or 8.');
end

BW = logical(BW);
if ~any(BW(:))
    error('boundaryFollow:EmptyImage', 'BW contains no foreground pixels.');
end

if conn == 8
    % 逆时针：
    % offsets = [0 1; -1 1; -1 0; -1 -1; 0 -1; 1 -1; 1 0; 1 1];
    % 顺时针：
    offsets = [0 1; 1 1; 1 0; 1 -1; 0 -1; -1 -1; -1 0; -1 1];
else
    % 逆时针：
    % offsets = [0 1; -1 0; 0 -1; 1 0];
    % 顺时针：
    offsets = [0 1; 1 0; 0 -1; -1 0];
end

[startRow, startCol] = find(BW, 1, 'first');
start = [startRow, startCol];
current = start;
previous = start + [0, -1];

boundary = zeros(numel(BW), 2);
boundary(1, :) = start;
count = 1;
secondPoint = [];
stopReason = 'maximum iteration guard reached';
maxSteps = 4 * numel(BW);

for step = 1:maxSteps
    prevIdx = neighborIndex(current, previous, offsets);
    if prevIdx == 0
        searchStart = 1;
    else
        searchStart = mod(prevIdx, size(offsets, 1)) + 1;
    end

    next = [];
    nextPrevious = [];
    for k = 0:size(offsets, 1)-1
        idx = mod(searchStart - 1 + k, size(offsets, 1)) + 1;
        candidate = current + offsets(idx, :);

        if candidate(1) < 1 || candidate(1) > size(BW, 1) || ...
           candidate(2) < 1 || candidate(2) > size(BW, 2)
            continue;
        end

        if BW(candidate(1), candidate(2))
            next = candidate;
            prevIdxForNext = mod(idx - 2, size(offsets, 1)) + 1;
            nextPrevious = current + offsets(prevIdxForNext, :);
            break;
        end
    end

    if isempty(next)
        stopReason = 'isolated foreground pixel';
        break;
    end

    previousBoundary = current;
    previous = nextPrevious;
    current = next;

    if isempty(secondPoint)
        secondPoint = current;
    elseif isequal(current, start) && ...
           ~isequal(previousBoundary, secondPoint) && ...
           isequal(nextPointAfterStart(BW, current, previous, offsets), secondPoint)
        stopReason = 'returned to start point and initial direction';
        break;
    end

    count = count + 1;
    boundary(count, :) = current;
end

boundary = boundary(1:count, :);

info = struct();
info.startPoint = start;
info.length = size(boundary, 1);
info.connectivity = conn;
info.stopReason = stopReason;
info.orientation = boundaryOrientation(boundary);
end

function idx = neighborIndex(center, point, offsets)
delta = point - center;
idx = find(offsets(:, 1) == delta(1) & offsets(:, 2) == delta(2), 1);
if isempty(idx)
    idx = 0;
end
end

function next = nextPointAfterStart(BW, current, previous, offsets)
prevIdx = neighborIndex(current, previous, offsets);
if prevIdx == 0
    searchStart = 1;
else
    searchStart = mod(prevIdx, size(offsets, 1)) + 1;
end

next = [];
for k = 0:size(offsets, 1)-1
    idx = mod(searchStart - 1 + k, size(offsets, 1)) + 1;
    candidate = current + offsets(idx, :);

    if candidate(1) < 1 || candidate(1) > size(BW, 1) || ...
       candidate(2) < 1 || candidate(2) > size(BW, 2)
        continue;
    end

    if BW(candidate(1), candidate(2))
        next = candidate;
        return;
    end
end
end

function orientation = boundaryOrientation(boundary)
if size(boundary, 1) < 3
    orientation = 'undefined';
    return;
end

x = boundary(:, 2);
y = boundary(:, 1);
x2 = x([2:end 1]);
y2 = y([2:end 1]);
signedArea2 = sum(x .* y2 - x2 .* y);

if signedArea2 > 0
    orientation = 'clockwise';
elseif signedArea2 < 0
    orientation = 'counterclockwise';
else
    orientation = 'undefined';
end
end
