% Project 11-01: Boundary Following
clear; close all; clc;

%% 1. Read input image
inputCandidates = {'Fig0914.tif', 'Fig0914.png', 'Fig0914.jpg'};
inputFile = '';
sourceName = 'synthetic_test_image';

for k = 1:numel(inputCandidates)
    if exist(inputCandidates{k}, 'file')
        inputFile = inputCandidates{k};
        break;
    end
end

if isempty(inputFile)
    fprintf('Fig. 9.14(a) was not found.');
else
    fprintf('Using input image: %s\n', inputFile);
    img = imread(inputFile);
    if ndims(img) == 3
        gray = im2double(rgb2gray(img));
    else
        gray = im2double(img);
    end
    [~, sourceName, ~] = fileparts(inputFile);
end

%% 2. Convert to binary
BW = localBinarize(gray);
BW = extractLargestComponent(BW, 8);
% Padding
BWp = padarray(BW, [1 1], false, 'both');

%% 3. Follow the outer boundary.
[boundaryPadded, info] = boundaryFollow(BWp, 8);
boundary = boundaryPadded - 1;

boundaryImage = false(size(BW));
valid = boundary(:, 1) >= 1 & boundary(:, 1) <= size(BW, 1) & ...
        boundary(:, 2) >= 1 & boundary(:, 2) <= size(BW, 2);
idx = sub2ind(size(BW), boundary(valid, 1), boundary(valid, 2));
boundaryImage(idx) = true;

fprintf('Boundary following finished.\n');
fprintf('  Start pixel      : row=%d, col=%d\n', boundary(1, 1), boundary(1, 2));
fprintf('  Boundary length  : %d pixels\n', size(boundary, 1));
fprintf('  Stop reason      : %s\n', info.stopReason);
fprintf('  Direction        : %s\n', info.orientation);

%% 4. Save file and Plot
if ~exist('results', 'dir')
    mkdir('results');
end

csvPath = fullfile('results', [sourceName '_boundary_points.csv']);
maskPath = fullfile('results', [sourceName '_boundary_mask.png']);
overlayPath = fullfile('results', [sourceName '_boundary_overlay.png']);
figPath = fullfile('results', [sourceName '_boundary_result.png']);

if exist('writematrix', 'file')
    writematrix(boundary, csvPath);
else
    dlmwrite(csvPath, boundary, 'delimiter', ',');
end
imwrite(boundaryImage, maskPath);
imwrite(localOverlay(gray, boundaryImage), overlayPath);

fig = figure('Name', 'Proj11-01 Boundary Following', ...
    'Position', [100, 100, 1100, 360]);

subplot(1, 3, 1);
imshow(gray, []);
title('Input image', 'FontSize', 12);

subplot(1, 3, 2);
imshow(BW);
title('Largest binary object', 'FontSize', 12);

subplot(1, 3, 3);
imshow(localOverlay(gray, boundaryImage));
hold on;
plot(boundary(:, 2), boundary(:, 1), 'y-', 'LineWidth', 1.0);
plot(boundary(1, 2), boundary(1, 1), 'go', 'MarkerSize', 7, 'LineWidth', 1.2);
hold off;
title(sprintf('Ordered boundary (%d points)', size(boundary, 1)), 'FontSize', 12);

if exist('exportgraphics', 'file')
    exportgraphics(fig, figPath, 'Resolution', 180);
else
    saveas(fig, figPath);
end

fprintf('Saved results:\n');
fprintf('  %s\n', csvPath);
fprintf('  %s\n', maskPath);
fprintf('  %s\n', overlayPath);
fprintf('  %s\n', figPath);

%% ------------------------------------------------------------------------
function BW = localBinarize(gray)
gray = im2double(gray);

if islogical(gray)
    BW = gray;
    if foregroundTouchesBorder(BW) && ~foregroundTouchesBorder(~BW)
        BW = ~BW;
    end
    return;
end

if numel(unique(gray(:))) <= 2
    BW = gray > mean(gray(:));
    if foregroundTouchesBorder(BW) && ~foregroundTouchesBorder(~BW)
        BW = ~BW;
    end
    return;
end

% Otsu thresholding
counts = histcounts(gray(:), 0:1/256:1);
p = counts(:) / numel(gray);
omega = cumsum(p);
mu = cumsum((0:255)' .* p);
muT = mu(end);
sigmaB2 = (muT * omega - mu).^2 ./ max(omega .* (1 - omega), eps);
[~, t] = max(sigmaB2);
threshold = (t - 1) / 255;

BW1 = gray > threshold;
BW2 = ~BW1;

% usually the smaller foreground.
if sum(BW1(:)) <= sum(BW2(:))
    BW = BW1;
else
    BW = BW2;
end

% check the foreground 是否接触边界
if foregroundTouchesBorder(BW) && ~foregroundTouchesBorder(~BW)
    BW = ~BW;
end
end

function tf = foregroundTouchesBorder(BW)
tf = any(BW(1, :)) || any(BW(end, :)) || any(BW(:, 1)) || any(BW(:, end));
end

function rgb = localOverlay(gray, mask)
gray = im2uint8(mat2gray(gray));
rgb = repmat(gray, [1 1 3]);
alpha = 0.75;

red = double(rgb(:, :, 1));
green = double(rgb(:, :, 2));
blue = double(rgb(:, :, 3));

red(mask) = (1 - alpha) * red(mask) + alpha * 255;
green(mask) = (1 - alpha) * green(mask);
blue(mask) = (1 - alpha) * blue(mask);

rgb(:, :, 1) = uint8(red);
rgb(:, :, 2) = uint8(green);
rgb(:, :, 3) = uint8(blue);
end
