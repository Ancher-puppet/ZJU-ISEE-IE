function out = extractLargestComponent(BW, conn)
%EXTRACTLARGESTCOMPONENT Keep the largest connected foreground component.

if nargin < 2
    conn = 8;
end

if conn == 8
    offsets = [-1 -1; -1 0; -1 1; 0 -1; 0 1; 1 -1; 1 0; 1 1];
elseif conn == 4
    offsets = [-1 0; 0 -1; 0 1; 1 0];
else
    error('extractLargestComponent:InvalidConnectivity', ...
        'Connectivity must be 4 or 8.');
end

BW = logical(BW);
[rows, cols] = size(BW);
visited = false(rows, cols);
bestPixels = [];

for r = 1:rows
    for c = 1:cols
        if ~BW(r, c) || visited(r, c)
            continue;
        end

        pixels = floodFillComponent(BW, visited, r, c, offsets);
        visited(pixels) = true;

        if numel(pixels) > numel(bestPixels)
            bestPixels = pixels;
        end
    end
end

out = false(rows, cols);
out(bestPixels) = true;
end

function pixels = floodFillComponent(BW, visited, r0, c0, offsets)
[rows, cols] = size(BW);
queue = zeros(numel(BW), 1);
pixels = zeros(numel(BW), 1);
head = 1;
tail = 1;
count = 1;

startIdx = sub2ind([rows, cols], r0, c0);
queue(tail) = startIdx;
pixels(count) = startIdx;
visited(startIdx) = true;

while head <= tail
    [r, c] = ind2sub([rows, cols], queue(head));
    head = head + 1;

    for k = 1:size(offsets, 1)
        nr = r + offsets(k, 1);
        nc = c + offsets(k, 2);

        if nr < 1 || nr > rows || nc < 1 || nc > cols
            continue;
        end

        idx = sub2ind([rows, cols], nr, nc);
        if BW(idx) && ~visited(idx)
            visited(idx) = true;
            tail = tail + 1;
            count = count + 1;
            queue(tail) = idx;
            pixels(count) = idx;
        end
    end
end

pixels = pixels(1:count);
end
