clear; clc; close all;

% 1. 读取图像
try
    img = imread('fig.tiff'); 
catch
    warning('未找到原图');
end

R = img(:,:,1);
G = img(:,:,2);
B = img(:,:,3);

num_pixels = numel(R);
L = 256; 

%% 对 R, G, B 进行直方图均衡化

% PDF
hist_R = imhist(R);
hist_G = imhist(G);
hist_B = imhist(B);
pdf_R = hist_R / num_pixels;
pdf_G = hist_G / num_pixels;
pdf_B = hist_B / num_pixels;

% CDF
cdf_R = cumsum(pdf_R);
cdf_G = cumsum(pdf_G);
cdf_B = cumsum(pdf_B);

% T(r)
T_R = round((L - 1) * cdf_R);
T_G = round((L - 1) * cdf_G);
T_B = round((L - 1) * cdf_B);

% 映射
R_eq_ind = int16(R) + 1; 
G_eq_ind = int16(G) + 1;
B_eq_ind = int16(B) + 1;
R_eqA = uint8(T_R(R_eq_ind));
G_eqA = uint8(T_G(G_eq_ind));
B_eqA = uint8(T_B(B_eq_ind));

% 拼接cat
img_out_A = cat(3, R_eqA, G_eqA, B_eqA);
imwrite(img_out_A, 'result_A.tif');

%% 使用平均直方图进行联合均衡化

% pdf、cdf
hist_avg = (hist_R + hist_G + hist_B) / 3;
pdf_avg = hist_avg / num_pixels;
cdf_avg = cumsum(pdf_avg);

% T(r)
T_avg = round((L - 1) * cdf_avg);

% 将统一变换函数应用于原图的三个通道
R_eqB = uint8(T_avg(R_eq_ind));
G_eqB = uint8(T_avg(G_eq_ind));
B_eqB = uint8(T_avg(B_eq_ind));

% 拼接cat
img_out_B = cat(3, R_eqB, G_eqB, B_eqB);
imwrite(img_out_B, 'result_B.jpg');
imwrite(img_out_B, 'result_B.tif');

%% fig1:
figure('Name', '图像处理结果', 'Position', [100, 500, 1200, 400]);

subplot(1,3,1);
imshow(img);
title('Original Image');

subplot(1,3,3);
imshow(img_out_A);
title('Separate RGB Equalization');

subplot(1,3,2);
imshow(img_out_B);
title('Average Histogram Equalization');

%% fig2:
figure('Name', 'PDF 分布与映射函数分析', 'Position', [100, 50, 1400, 600]);

% 1. R 通道 PDF
subplot(2, 4, 1);
bar(0:255, pdf_R, 'r', 'EdgeColor', 'none');
title('R Channel PDF'); 
xlim([0 255]); xlabel('Intensity'); ylabel('Probability');

% 2. G 通道 PDF
subplot(2, 4, 2);
bar(0:255, pdf_G, 'g', 'EdgeColor', 'none');
title('G Channel PDF'); 
xlim([0 255]); xlabel('Intensity');

% 3. B 通道 PDF
subplot(2, 4, 3);
bar(0:255, pdf_B, 'b', 'EdgeColor', 'none');
title('B Channel PDF'); 
xlim([0 255]); xlabel('Intensity');

% 4. 整体(平均) PDF
subplot(2, 4, 4);
bar(0:255, pdf_avg, 'k', 'EdgeColor', 'none');
title('Average/Overall PDF'); 
xlim([0 255]); xlabel('Intensity');

% 5. R 通道映射函数
subplot(2, 4, 5);
plot(0:255, T_R, 'r', 'LineWidth', 2);
title('R Mapping Function T_R(r)'); 
xlim([0 255]); ylim([0 255]); 
xlabel('Input r'); ylabel('Output s'); grid on;

% 6. G 通道映射函数
subplot(2, 4, 6);
plot(0:255, T_G, 'g', 'LineWidth', 2);
title('G Mapping Function T_G(r)'); 
xlim([0 255]); ylim([0 255]); 
xlabel('Input r'); grid on;

% 7. B 通道映射函数
subplot(2, 4, 7);
plot(0:255, T_B, 'b', 'LineWidth', 2);
title('B Mapping Function T_B(r)'); 
xlim([0 255]); ylim([0 255]); 
xlabel('Input r'); grid on;

% 8. 整体(平均)映射函数
subplot(2, 4, 8);
plot(0:255, T_avg, 'k', 'LineWidth', 2);
title('Average Mapping Function T_{avg}(r)'); 
xlim([0 255]); ylim([0 255]); 
xlabel('Input r'); grid on;