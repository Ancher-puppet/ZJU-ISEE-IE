function seeds = autoSelectSeeds(img, numSeeds, minDist)
% 自动选取区域生长的种子点

if nargin < 3
    minDist = 20;
end
if nargin < 2
    numSeeds = 4;
end

imgD = im2double(img);

% Step 1: 高斯平滑
h = fspecial('gaussian', [5, 5], 1.0);
imgSmooth = imfilter(imgD, h, 'replicate');

% Step 2: 局部极大值
localMax = imregionalmax(imgSmooth, 8);
[maxRows, maxCols] = find(localMax);
maxVals = imgD(localMax);

% Step 3: 降序排序
[sortedVals, sortIdx] = sort(maxVals, 'descend');
sortedRows = maxRows(sortIdx);
sortedCols = maxCols(sortIdx);

% Step 4: 空间去重
seeds = [];
for i = 1:length(sortedRows)
    r = sortedRows(i);
    c = sortedCols(i);

    if isempty(seeds)
        seeds = [r, c];
    else
        dists = sqrt((seeds(:,1) - r).^2 + (seeds(:,2) - c).^2);
        if min(dists) >= minDist
            seeds = [seeds; r, c];
        end
    end

    if size(seeds, 1) >= numSeeds
        break;
    end
end
end
