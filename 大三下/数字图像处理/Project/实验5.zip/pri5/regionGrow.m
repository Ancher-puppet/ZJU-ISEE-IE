function [regionMask, regionMean] = regionGrow(img, seeds, threshold)
% 基于8邻域的区域生长算法
imgD = im2double(img);
[rows, cols] = size(imgD);


regionMask = false(rows, cols);
numSeeds = size(seeds, 1);
seedIndices = zeros(numSeeds, 1);
for i = 1:numSeeds
    r = max(1, min(rows, round(seeds(i, 1))));
    c = max(1, min(cols, round(seeds(i, 2))));
    regionMask(r, c) = true;
    seedIndices(i) = sub2ind([rows, cols], r, c);
end

% 初始均值
regionPixels = imgD(regionMask);
regionMean = mean(regionPixels);
activeList = seedIndices;

% 8连通
neighborOffsets = [-1, -1; -1, 0; -1, 1;
                    0, -1;          0, 1;
                    1, -1;  1, 0;  1, 1];

% region 生长
maxIter = rows * cols; 
iter = 0;
changed = true;

while changed && iter < maxIter
    changed = false;
    iter = iter + 1;

    newActiveList = [];
    candidateSet = false(rows, cols);

    for i = 1:length(activeList)
        [r, c] = ind2sub([rows, cols], activeList(i));

        for k = 1:8
            nr = r + neighborOffsets(k, 1);
            nc = c + neighborOffsets(k, 2);

            if nr < 1 || nr > rows || nc < 1 || nc > cols
                continue;
            end

            if ~regionMask(nr, nc) && ~candidateSet(nr, nc)
                candidateSet(nr, nc) = true;
            end
        end
    end

    [candRows, candCols] = find(candidateSet);
    for cIdx = 1:length(candRows)
        nr = candRows(cIdx);
        nc = candCols(cIdx);

        % 相似性准则 < threshold
        if abs(imgD(nr, nc) - regionMean) <= threshold
            regionMask(nr, nc) = true;
            newActiveList = [newActiveList; sub2ind([rows, cols], nr, nc)];
            changed = true;
        end
    end

    if changed
        activeList = newActiveList;
        regionPixels = imgD(regionMask);
        regionMean = mean(regionPixels);
    end
end

if iter >= maxIter
    warning('regionGrow: 达到最大迭代次数 %d，可能未完全收敛。', maxIter);
end
end
