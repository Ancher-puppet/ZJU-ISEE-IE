function [segmented, numRegions] = splitMerge(img, splitThresh, mergeThresh, minBlockSize)
% 基于四叉树的区域分裂与合并算法

imgD = im2double(img);
[origRows, origCols] = size(imgD);

% padding
maxDim = max(origRows, origCols);
pow2Size = 2^nextpow2(maxDim);
padRows = pow2Size - origRows;
padCols = pow2Size - origCols;
imgPadded = padarray(imgD, [padRows, padCols], 'symmetric', 'post');

%% 1. 四叉树分裂

S = qtdecomp(imgPadded, splitThresh, minBlockSize);
[ii, jj, ss] = find(S);

% 处理不同尺寸的块
uniqueSizes = unique(ss);
labelCount = 0;
labels = zeros(pow2Size, pow2Size);

for k = 1:length(uniqueSizes)
    blkSize = uniqueSizes(k);
    idx = find(ss == blkSize);

    for m = 1:length(idx)
        r = ii(idx(m));
        c = jj(idx(m));
        labelCount = labelCount + 1;
        labels(r:r+blkSize-1, c:c+blkSize-1) = labelCount;
    end
end

numBlocks = labelCount;
regionMean = zeros(numBlocks, 1);
regionPixelCount = zeros(numBlocks, 1);
regionMin = zeros(numBlocks, 1);
regionMax = zeros(numBlocks, 1);

for i = 1:numBlocks
    mask = (labels == i);
    pixels = imgPadded(mask);
    regionMean(i) = mean(pixels);
    regionPixelCount(i) = sum(mask(:));
    regionMin(i) = min(pixels);
    regionMax(i) = max(pixels);
end

fprintf('  分裂后块数: %d\n', numBlocks);

%% 2.区域合并
% 构建区域邻接图
adjacency = buildAdjacency(labels, numBlocks);

merged = true;
mergeIter = 0;
maxMergeIter = numBlocks;

while merged && mergeIter < maxMergeIter
    merged = false;
    mergeIter = mergeIter + 1;

    [r1, r2] = find(triu(adjacency, 1));

    for p = 1:length(r1)
        i = r1(p);
        j = r2(p);

        if ~adjacency(i, j)
            continue;
        end

        unionMin = min(regionMin(i), regionMin(j));
        unionMax = max(regionMax(i), regionMax(j));
        if unionMax - unionMin <= mergeThresh
            % 合并区域 j 到 i
            labels(labels == j) = i;
            totalPixels = regionPixelCount(i) + regionPixelCount(j);
            regionMean(i) = (regionMean(i) * regionPixelCount(i) + ...
                             regionMean(j) * regionPixelCount(j)) / totalPixels;
            regionPixelCount(i) = totalPixels;
            regionMin(i) = unionMin;
            regionMax(i) = unionMax;
            % j 为已合并
            regionMean(j) = NaN;
            regionPixelCount(j) = 0;
            regionMin(j) = NaN;
            regionMax(j) = NaN;
            % j 的邻接转移给 i
            adjacency(i, :) = adjacency(i, :) | adjacency(j, :);
            adjacency(:, i) = adjacency(:, i) | adjacency(:, j);
            adjacency(j, :) = false;
            adjacency(:, j) = false;
            adjacency(i, i) = false;
            merged = true;
        end
    end
end

validRegions = ~isnan(regionMean);
validIndices = find(validRegions);
numRegions = length(validIndices);
newLabels = zeros(pow2Size, pow2Size);
for newId = 1:numRegions
    newLabels(labels == validIndices(newId)) = newId;
end

% 逆 padding
segmented = newLabels(1:origRows, 1:origCols);

fprintf('  合并后区域数: %d\n', numRegions);
end

% ======================================================================
function adj = buildAdjacency(labels, numRegions)
[rows, cols] = size(labels);
adj = false(numRegions, numRegions);

for r = 1:rows
    for c = 1:cols-1
        if labels(r, c) ~= labels(r, c+1)
            a = labels(r, c);
            b = labels(r, c+1);
            if a > 0 && b > 0
                adj(a, b) = true;
                adj(b, a) = true;
            end
        end
    end
end

for r = 1:rows-1
    for c = 1:cols
        if labels(r, c) ~= labels(r+1, c)
            a = labels(r, c);
            b = labels(r+1, c);
            if a > 0 && b > 0
                adj(a, b) = true;
                adj(b, a) = true;
            end
        end
    end
end
end
