%  Region Growing & Region Splitting/Merging
clear; close all;

%% 加载图像
imgGray = imread('Fig1039(a）.tif');
if size(imgGray, 3) >= 3, imgGray = rgb2gray(imgGray); end
imgGray = uint8(imgGray);
[rows, cols] = size(imgGray);
totalPixels = rows * cols;

fprintf('Image: %dx%d, range [%d,%d], mean=%.1f, std=%.1f\n', ...
    cols, rows, min(imgGray(:)), max(imgGray(:)), ...
    mean(double(imgGray(:))), std(double(imgGray(:))));

%% 自动种子点选取
numSeeds = 4;
minDist = 30;
seeds = autoSelectSeeds(imgGray, numSeeds, minDist);

fprintf('Found %d seeds:\n', size(seeds, 1));
for i = 1:size(seeds, 1)
    fprintf('  (%d,%d) intensity=%d\n', seeds(i,1), seeds(i,2), imgGray(seeds(i,1), seeds(i,2)));
end


%% 区域生长 RG

fprintf('\n--- Part A: Region Growing ---\n');
growT = [0.03, 0.06, 0.10, 0.15];

figure('Name', 'Region Growing', 'Position', [100, 200, 1200, 500]);
growMasks = cell(length(growT), 1);
growPx = zeros(length(growT), 1);

for t = 1:length(growT)
    T = growT(t);
    [rawGrowMask, ~] = regionGrow(imgGray, seeds, T);
    % 区域生长后显式保留面积最大的两个连通域
    growMasks{t} = keepLargestComponents(rawGrowMask, 2);
    growPx(t) = sum(growMasks{t}(:));
    pct = 100 * growPx(t) / totalPixels;
    fprintf('  T=%.2f  ->  %d px (%.1f%%), top-2 CC kept\n', T, growPx(t), pct);

    subplot(2, 4, t);
    imshow(growMasks{t});
    title(sprintf('T=%.2f Top-2, %d px (%.1f%%)', T, growPx(t), pct), 'FontSize', 11);

    subplot(2, 4, t + 4);
    imshow(localOverlay(imgGray, growMasks{t}, [1, 0, 0]));
    title(sprintf('Overlay T=%.2f Top-2', T), 'FontSize', 11);
end

% 选最佳 T
validT = growPx > 0.01*totalPixels & growPx < 0.30*totalPixels;
if any(validT)
    candidates = growPx(validT);
    [~, idx] = min(candidates);  
    idxs = find(validT);
    bestGrowIdx = idxs(idx);
else
    [~, bestGrowIdx] = min(growPx);
end
bestGrowT = growT(bestGrowIdx);
bestGrowMask = growMasks{bestGrowIdx};
bestGrowPx = growPx(bestGrowIdx);
fprintf('  -> Best T=%.2f, %d px (%.1f%%)\n', bestGrowT, bestGrowPx, 100*bestGrowPx/totalPixels);


%% 区域分裂与合并 SM
fprintf('\n--- Part B: Split & Merge ---\n');

splitVals  = [0.02, 0.04, 0.08];
mergeVals  = [0.02, 0.04, 0.06];
minBlock   = 4; 

smResults = cell(length(splitVals), length(mergeVals));
smPixels  = zeros(length(splitVals), length(mergeVals));
smRegions = zeros(length(splitVals), length(mergeVals));

imgD = im2double(imgGray);
globalMean = mean(imgD(:));
globalStd  = std(imgD(:));
brightThresh = globalMean + 1.5 * globalStd; 

fprintf('  Global mean=%.4f, std=%.4f, bright threshold=%.4f\n', ...
    globalMean, globalStd, brightThresh);

figure('Name', 'Split & Merge', 'Position', [100, 100, 1200, 800]);

for si = 1:length(splitVals)
    for mi = 1:length(mergeVals)
        Ts = splitVals(si);
        Tm = mergeVals(mi);

        [lbl, nReg] = splitMerge(imgGray, Ts, Tm, minBlock);

        ul = unique(lbl(:)); ul = ul(ul > 0);
        rMean = zeros(length(ul), 1);
        for i = 1:length(ul)
            rMean(i) = mean(imgD(lbl == ul(i)));
        end
        bright = ul(rMean > brightThresh);
        smBin = ismember(lbl, bright);
        % 只保留两个最大亮环连通域。
        smBin = keepLargestComponents(smBin, 2);

        smResults{si, mi} = smBin;
        smPixels(si, mi)  = sum(smBin(:));
        smRegions(si, mi) = nReg;

        sp = (si-1)*3 + mi;
        subplot(3, 3, sp);
        imshow(smBin);
        title(sprintf('Ts=%.2f Tm=%.2f Top-2\n%d regions, %d px (%.1f%%)', ...
            Ts, Tm, nReg, smPixels(si,mi), 100*smPixels(si,mi)/totalPixels), 'FontSize', 9);

        fprintf('  Ts=%.2f Tm=%.2f  ->  %d regions, %d px (%.1f%%)\n', ...
            Ts, Tm, nReg, smPixels(si,mi), 100*smPixels(si,mi)/totalPixels);
    end
end

% 选最优
[~, bestSMidx] = min(abs(smPixels(:) - bestGrowPx));
[bestSMsi, bestSMmi] = ind2sub([length(splitVals), length(mergeVals)], bestSMidx);
bestSplitT = splitVals(bestSMsi);
bestMergeT = mergeVals(bestSMmi);
splitMergeBinary = smResults{bestSMsi, bestSMmi};
bestNumRegions = smRegions(bestSMsi, bestSMmi);

fprintf('  -> Selected: Ts=%.2f Tm=%.2f, %d regions, %d px (%.1f%%)\n', ...
    bestSplitT, bestMergeT, bestNumRegions, ...
    sum(splitMergeBinary(:)), 100*sum(splitMergeBinary(:))/totalPixels);

%% 最终对比
fprintf('\n--- Final Comparison ---\n');

figure('Name', 'Final Comparison', 'Position', [100, 100, 1200, 350]);

subplot(1, 4, 1);
imshow(imgGray);
title('Original  Fig.10.39(a)', 'FontSize', 12);

subplot(1, 4, 2);
imshow(localOverlay(imgGray, bestGrowMask, [1, 0, 0]));
title(sprintf('Region Growing Top-2\nT=%.2f, %d px (%.1f%%)', ...
    bestGrowT, bestGrowPx, 100*bestGrowPx/totalPixels), 'FontSize', 12);

subplot(1, 4, 3);
imshow(localOverlay(imgGray, splitMergeBinary, [0, 1, 0]));
title(sprintf('Split & Merge Top-2 (auto-matched)\nTs=%.2f Tm=%.2f, %d regions', ...
    bestSplitT, bestMergeT, bestNumRegions), 'FontSize', 12);

subplot(1, 4, 4);
combo = cat(3, double(bestGrowMask), double(splitMergeBinary), zeros(size(bestGrowMask)));
imshow(combo);
title('R: Grow  G: SplitMerge', 'FontSize', 12);

%% ======================================================================
function rgb = localOverlay(grayImg, mask, color)
grayImg = im2uint8(grayImg);
rgbBg = repmat(grayImg, [1, 1, 3]);
rgb = rgbBg;
alpha = 0.4;
for ch = 1:3
    chan = double(rgbBg(:,:,ch));
    chan(mask) = (1-alpha)*chan(mask) + alpha*color(ch)*255;
    rgb(:,:,ch) = uint8(chan);
end
end

function d = dice(A, B)
inter = sum(A(:) & B(:));
denom = sum(A(:)) + sum(B(:));
if denom > 0, d = 2*inter/denom; else, d = 0; end
end

function filtered = keepLargestComponents(mask, nKeep)
if nargin < 2
    nKeep = 2;
end
CC = bwconncomp(mask);
filtered = false(size(mask));
if CC.NumObjects == 0
    return;
end
numPixels = cellfun(@numel, CC.PixelIdxList);
[~, sortedIdx] = sort(numPixels, 'descend');
for k = 1:min(nKeep, numel(sortedIdx))
    filtered(CC.PixelIdxList{sortedIdx(k)}) = true;
end
end
