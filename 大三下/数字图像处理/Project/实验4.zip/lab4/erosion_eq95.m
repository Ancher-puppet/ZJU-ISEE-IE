function output_img = erosion_eq95(input_img, SE)
    [rows, cols] = size(input_img);
    [s_rows, s_cols] = size(SE);
    
    pad_r = floor(s_rows / 2);
    pad_c = floor(s_cols / 2);    
    padded_img = padarray(input_img, [pad_r, pad_c], 0, 'both');
    
    % A 的补集 (A^c)
    Ac_padded = ~padded_img;     
    output_img = false(rows, cols);
    SE_logical = logical(SE);
    
    for i = 1:rows
        for j = 1:cols
            window_Ac = Ac_padded(i : i+s_rows-1, j : j+s_cols-1);
            intersection = window_Ac(SE_logical);
            if ~any(intersection)
                output_img(i, j) = 1;
            else
                output_img(i, j) = 0;
            end
        end
    end
end