function output_img = erosion(input_img, SE)
    [rows, cols] = size(input_img);
    [s_rows, s_cols] = size(SE);
    
    pad_r = floor(s_rows / 2);
    pad_c = floor(s_cols / 2);
    
    padded_img = padarray(input_img, [pad_r, pad_c], 0, 'both');
    output_img = false(rows, cols);
    
    SE_logical = logical(SE);
    
    for i = 1:rows
        for j = 1:cols
            window = padded_img(i : i+s_rows-1, j : j+s_cols-1);
            if all(window(SE_logical) == 1)
                output_img(i, j) = 1;
            else
                output_img(i, j) = 0;
            end
        end
    end
end