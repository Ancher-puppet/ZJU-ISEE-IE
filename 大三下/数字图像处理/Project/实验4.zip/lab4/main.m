clear; clc; close all;

%% 生成二值图像和SE
% 初始化 7x15 的全 0 背景
img = zeros(7, 15);

% 构建主体蓝色区域
img(2:6, 2:5) = 1;
img(2:6, 11:14) = 1;
img(3:5, 6:10) = 1;  

% 挖去中间的两个白色空洞
img(4, 6) = 0;
img(4, 10) = 0;

% 转换为逻辑矩阵
img = logical(img);

SE = ones(3, 3);

%% 形态学计算
% 腐蚀: A ⊖ B
eroded_img = erosion(img, SE);
eroded_img_eq95 = erosion_eq95(img,SE);

% boundary extraction: A - (A ⊖ B)
boundary_img = img & ~eroded_img;

%% 可视化
figure('Name', 'Morphological Boundary Extraction', 'Position', [100, 100, 1200, 300]);

% 获取图像尺寸
[M, N] = size(img);
x_edges = 0.5 : 1 : N+0.5;
y_edges = 0.5 : 1 : M+0.5;

% 1. 原始图像 A
subplot(2, 2, 1);
imshow(img, 'InitialMagnification', 'fit');
title('Original Image $A$', 'Interpreter', 'latex', 'FontSize', 16);
axis on;
set(gca, 'XTick', x_edges, 'YTick', y_edges, 'XTickLabel', [], 'YTickLabel', [], ...
         'GridColor', [0.4 0.4 0.4], 'GridAlpha', 0.8, 'LineWidth', 1);
grid on;

% 2. 腐蚀后的图像
subplot(2, 2, 2);
imshow(eroded_img, 'InitialMagnification', 'fit');
title('Eroded Image $A \ominus B$', 'Interpreter', 'latex', 'FontSize', 16);
axis on;
set(gca, 'XTick', x_edges, 'YTick', y_edges, 'XTickLabel', [], 'YTickLabel', [], ...
         'GridColor', [0.4 0.4 0.4], 'GridAlpha', 0.8, 'LineWidth', 1);
grid on;

subplot(2, 2, 3);
imshow(eroded_img_eq95, 'InitialMagnification', 'fit');
title('Eroded Eq95 Image $A \ominus B$', 'Interpreter', 'latex', 'FontSize', 16);
axis on;
set(gca, 'XTick', x_edges, 'YTick', y_edges, 'XTickLabel', [], 'YTickLabel', [], ...
         'GridColor', [0.4 0.4 0.4], 'GridAlpha', 0.8, 'LineWidth', 1);
grid on;

% 3. 提取的边界
subplot(2, 2, 4);
imshow(boundary_img, 'InitialMagnification', 'fit');
title('Boundary $\beta(A) = A - (A \ominus B)$', 'Interpreter', 'latex', 'FontSize', 16);
axis on;
set(gca, 'XTick', x_edges, 'YTick', y_edges, 'XTickLabel', [], 'YTickLabel', [], ...
         'GridColor', [0.4 0.4 0.4], 'GridAlpha', 0.8, 'LineWidth', 1);
grid on;
