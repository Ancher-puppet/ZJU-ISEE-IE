clear; clc; close all;

%% 1. 读取图像与预处理
try
    fig = imread('figure.png'); 
catch
    fig = imread('coins.png');
end

if size(fig, 3) == 3
    fig = rgb2gray(fig);
end
fig = im2double(fig); % 归一化
[M, N] = size(fig);

%% 2. 频谱居中-Proj 04-01
[X, Y] = meshgrid(1:N, 1:M);
center_matrix = (-1).^(X + Y);
fig_centered = fig .* center_matrix;

%% 3. 二维FFT-Proj 04-01
F = fft2(fig_centered);
Spectrum = log(1 + abs(F)); 

%% 4. 高斯高通滤波器-Proj 04-04
D0 = 50; 

u = 1:M;
v = 1:N;
[V, U] = meshgrid(v, u);
D_sq = (U - M/2).^2 + (V - N/2).^2;

% Gaussian Lowpass Filter (GLPF)
H_LP = exp(-D_sq / (2 * D0^2));
% Gaussian Highpass Filter (GHPF)
H_HP = 1 - H_LP; 

%% 5. 频域滤波与逆变换-Proj 04-01
% 频域相乘
G = F .* H_HP;
g_centered = ifft2(G);
g = real(g_centered) .* center_matrix;

%% 6. 阈值处理-Proj 04-05
Threshold = 0.01;
g_thresholded = g > Threshold;

figure('Name', 'Project 04-05: Highpass Filtering & Thresholding', 'Position', [100, 100, 1200, 800]);

subplot(2, 3, 1);
imshow(fig, []);
title('Original Image');

subplot(2, 3, 2);
imshow(Spectrum, []);
title('Centered Fourier Spectrum');

subplot(2, 3, 3);
surf(H_HP, 'EdgeColor', 'none'); 
view(2); axis tight;
title(['Gaussian Highpass Filter (D_0 = ', num2str(D0), ')']);

subplot(2, 3, 4);
imshow(g, []);
title('Highpass Filtered Image');

subplot(2, 3, 5);
imshow(g, [-0.04,0.04]);
title('Highpass Filtered Image range 【-0.04，0.04】');

subplot(2, 3, 6);
imshow(g_thresholded, []);
title(['Thresholded Image (T > ', num2str(Threshold), ')']);