import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import csv  # 新增：用于将表格导出为文件

def compute_histogram(image):
    hist = np.bincount(image.ravel(), minlength=256)
    return hist

def histogram_equalization(image):
    hist = compute_histogram(image)
    
    total_pixels = image.shape[0] * image.shape[1]
    pdf = hist / total_pixels
    
    cdf = np.cumsum(pdf)
    
    transform_map = np.round(cdf * 255).astype(np.uint8)
    enhanced_image = transform_map[image]

    return enhanced_image, hist, pdf, cdf, transform_map

def export_and_print_table(hist, pdf, cdf, transform_map):
    
    # 创建csv 
    csv_filename = 'histogram_mapping_table.csv'
    with open(csv_filename, mode='w', newline='', encoding='utf-8-sig') as f:
        writer = csv.writer(f)
        writer.writerow(['r_k (原灰度)', 'n_k (像素数)', 'p_r (概率)', 'CDF (累加)', 's_k (精确值)', 's_k (均衡后)'])
        
        for i in range(256):
            exact_sk = cdf[i] * 255
            writer.writerow([i, hist[i], f"{pdf[i]:.6f}", f"{cdf[i]:.6f}", f"{exact_sk:.2f}", transform_map[i]])


def main():
    image_path = 'fig3_8a.jpg' 
    
    try:
        original_img = Image.open(image_path).convert('L')
        original_img = np.array(original_img)
    except FileNotFoundError:
        print(f"找不到图像文件: {image_path}。请检查路径或先使用测试矩阵。")
        original_img = np.random.normal(50, 15, (512, 512)).clip(0, 255).astype(np.uint8)

    # 【修改点】：接收多返回的 pdf 和 cdf
    enhanced_img, original_hist, pdf, cdf, transform_map = histogram_equalization(original_img)
    
    enhanced_hist = compute_histogram(enhanced_img)

    export_and_print_table(original_hist, pdf, cdf, transform_map)

    plt.figure(figsize=(15, 10))
    plt.subplots_adjust(hspace=0.4, wspace=0.3)

    plt.subplot(2, 3, 1)
    plt.imshow(original_img, cmap='gray', vmin=0, vmax=255)
    plt.title('1. Original Image')
    plt.axis('off')

    plt.subplot(2, 3, 2)
    plt.bar(range(256), original_hist, color='black', width=1)
    plt.title('2. Original Histogram')
    plt.xlabel('Intensity Value')
    plt.ylabel('Pixel Count')
    plt.xlim([0, 255])

    plt.subplot(2, 3, 3)
    plt.plot(range(256), transform_map, color='red', linewidth=2)
    plt.title('3. Transformation Function $T(r)$')
    plt.xlabel('Input Intensity $r$')
    plt.ylabel('Output Intensity $s$')
    plt.xlim([0, 255])
    plt.ylim([0, 255])
    plt.grid(True, linestyle='--', alpha=0.6)

    plt.subplot(2, 3, 4)
    plt.imshow(enhanced_img, cmap='gray', vmin=0, vmax=255)
    plt.title('4. Enhanced Image')
    plt.axis('off')

    plt.subplot(2, 3, 5)
    plt.bar(range(256), enhanced_hist, color='black', width=1)
    plt.title('5. Enhanced Histogram')
    plt.xlabel('Intensity Value')
    plt.ylabel('Pixel Count')
    plt.xlim([0, 255])

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()